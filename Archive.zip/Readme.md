**Modes of operation**
CUPCAKE modes
1.SHA 256 mode =0 H//Dont know how to use it yet.
2.SHA-512 mode =1  SHA 512
3.SHAKE 128 mode=2
4.SHAKE 256 mode =3


**STOP**
squeeze is used to stop generating output from shake whenever neccesary output is achieved
PULSE